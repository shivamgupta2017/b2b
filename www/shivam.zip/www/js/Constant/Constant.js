app.constant('Constant', 
{	
	base_url:{

		service_url:'http://minbazaar.com/admin/service/',
		image_url: 'http://minbazaar.com/admin/assets/uploads/product/'
	}
});